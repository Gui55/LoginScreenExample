package com.example.mergmultiactivities;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class CActivity extends AppCompatActivity {

    //A activity C

    private TextView textView; //Caixinha de mensagens
    private ConstraintLayout cl; //O constraint layout em si
    private Button botao;

    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c);

        builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.app_name).setTitle(R.string.app_name);

        textView = new TextView(this);
        textView.setText("DEVIL MAY CRY!!!");

        botao = new Button(this);
        botao.setText(getApplicationContext().getString(R.string.apertar));
        botao.setY(200f);

        cl = findViewById(R.id.cl);
        cl.addView(textView);
        cl.addView(botao);

        botao.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                builder.setPositiveButton("Ou não ser?", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        Toast.makeText(getApplicationContext(), "Tu escolhestes o não",
                                Toast.LENGTH_SHORT);

                        finish();
                    }
                });

                builder.setNegativeButton("Ser!", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        Toast.makeText(getApplicationContext(), "Tu escolhestes o sim",
                                Toast.LENGTH_SHORT);

                        finish();
                    }
                });

                AlertDialog alert = builder.create();
                alert.setTitle("Alerta");
                alert.show();

            }

        });

    }
}
