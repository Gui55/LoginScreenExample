package com.example.mergmultiactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class ActivityB extends AppCompatActivity {

    private TextView enterTextActB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);

        Intent intent = getIntent();

        String user = intent.getStringExtra("usuario");

        Toast.makeText(this, "Welcome "+user+"! DEVIL MAY CRY!!!!", Toast.LENGTH_SHORT).show();

        enterTextActB = (TextView)findViewById(R.id.enterTextActB);
        enterTextActB.setText("Welcome "+user);
    }
}
