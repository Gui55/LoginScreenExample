package com.example.mergmultiactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button botaozinho;
    private EditText enterText, enterTextB;

    private String user, senha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setListener();
    }

    void setListener(){
        botaozinho=(Button)findViewById(R.id.botaozinho);

        botaozinho.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View vew){

                //Toast.makeText(MainActivity.this, "DEVIL MAY CRY!!!!!",Toast.LENGTH_SHORT).show();

                String userU = enterText.getText().toString();
                String userP = enterTextB.getText().toString();

                if(userU.equals("gui") && userP.equals("123")){

                    Intent intent = new Intent(getApplicationContext(), LoadBarActivity.class);
                    intent.putExtra("usuario", userU);
                    intent.putExtra("password", userP);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Inválido",Toast.LENGTH_SHORT).show();
                }

            }

        });

        enterText=(EditText)findViewById(R.id.enterText);
        enterTextB=(EditText)findViewById(R.id.enterTextB);
    }
}
