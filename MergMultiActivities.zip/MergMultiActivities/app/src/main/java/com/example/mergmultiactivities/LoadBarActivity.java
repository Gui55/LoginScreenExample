package com.example.mergmultiactivities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

public class LoadBarActivity extends AppCompatActivity {

    private Button downButton; // Criação do botão de download
    private ProgressBar circulozinho; //Criação do círculo de carregamento
    private ConstraintLayout cllb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load_bar);

        //Configuração da ConstraintLayout
        cllb = findViewById(R.id.cllb);

        //Configuração do circulozinho criado no XML
        circulozinho = (ProgressBar)findViewById(R.id.circle);
        circulozinho.setIndeterminate(true); // rodinha rodando infinitamente

        //Configuração do botão de download
        downButton = new Button(this); // instância
        downButton.setText(getApplicationContext().getString(R.string.download)); // texto do botão
        downButton.setY(200f); // posição Y
        cllb.addView(downButton); // adiciona o botão no layout

        //O que acontece ao clicar no botão de download
        downButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(circulozinho.isShown()){
                    circulozinho.setVisibility(View.GONE);
                } else {
                    circulozinho.setVisibility(View.VISIBLE);
                }

            }
        });

    }
}
